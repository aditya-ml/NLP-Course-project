Steps for running code

1. Load dataset shared in google drive and specify correct path.

2. Install relevant libraries.

3. Run NLP_topic_modeling.ipynb to calculate performance metrics and generate topic keywords on the dataset using 4 different topic models.

4. Run Propagation_Graph.ipynb to calculate edge weights and generate graphs for inter-topic correlation.